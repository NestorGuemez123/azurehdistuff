from Poblacion_Desocupada import mainDesocupada
from Poblacion_Mayor import mainMayor 
from Poblacion_Ocupada import mainOcupada 
from Poblacion_Subocupada import mainSubocupada
from prepare import Prepare

def main():
    try:
        desocupada = mainDesocupada.MainDesocupada()
        mayor = mainMayor.MainMayor()
        ocupada = mainOcupada.MainOcupada()
        subocupada = mainSubocupada.MainSubocupada()
        prepare = Prepare()

        Poblacion_desocupada = desocupada.desocupada()
        Poblacion_mayor = mayor.mayor()
        Poblacion_ocupada = ocupada.ocupada()
        Poblacion_subocupada = subocupada.subocupada()

        df = prepare.prepared(Poblacion_desocupada,Poblacion_mayor,Poblacion_ocupada,Poblacion_subocupada)
        df.to_csv('DataPuebla.csv')
    except Exception as ex:
        print(ex)

if __name__ == '__main__':
    main()