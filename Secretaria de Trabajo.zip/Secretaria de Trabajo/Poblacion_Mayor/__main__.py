from Poblacion_mayor import PoblacionMayor
from read_file import ReadFile

def main():
    
    #Call the IENGI API Poblacion Ocupada
    Poblacion_mayor_total_mujeres = 'https://www.inegi.org.mx/app/api/indicadores/desarrolladores/jsonxml/INDICATOR/446911/es/0700/false/BIE/2.0/5e7385c4-b4eb-74a0-067d-bed192198099?type=json'
    Poblacion_mayor_total_hombres = 'https://www.inegi.org.mx/app/api/indicadores/desarrolladores/jsonxml/INDICATOR/446737/es/0700/false/BIE/2.0/5e7385c4-b4eb-74a0-067d-bed192198099?type=json'
    url_scraping= 'https://www.inegi.org.mx/sistemas/olap/proyectos/bd/encuestas/hogares/enoe/2010_pe_ed15/p15.asp?s=est&proy=enoe_pe_ed15_pmay&p=enoe_pe_ed15'

    leer_archivo = ReadFile()
    poblacion_mayor = PoblacionMayor()
    
    file_path, path_file, chromedrive_path = leer_archivo.readFile()
    Poblacion_Mayor_df = poblacion_mayor.execute(Poblacion_mayor_total_mujeres,Poblacion_mayor_total_hombres,url_scraping,file_path, path_file, chromedrive_path)
    
    print(Poblacion_Mayor_df)
    # End of code
    

if __name__ == "__main__":
    main()