import requests
import json
import pandas as pd
import numpy as np
import time

from selenium import webdriver 
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import Select


class PoblacionMayor():
    
    def  __init__(self):
        self.name = "PoblacionMayor"
    
    def execute (self,Poblacion_mayor_total_mujeres,Poblacion_mayor_total_hombres, url_scraping, file_path, path_file, chromedrive_path):
        df_total_hombres = self._total_hombres(Poblacion_mayor_total_hombres)
        df_total_mujeres = self._total_mujeres(Poblacion_mayor_total_mujeres)
        self._scrap(url_scraping, file_path, chromedrive_path)
        df_scrap_prepared = self._scrap_prepared(path_file)
        df_poblacion_mayor = self._poblacion_mayor(df_total_hombres,df_total_mujeres,df_scrap_prepared)

        return df_poblacion_mayor

    def _total_hombres (self,Poblacion_mayor_total_hombres):  #Prepare Total_Hombres
        response = requests.get(Poblacion_mayor_total_hombres)
        status = response.status_code 

        if status != 200:

            print("Error en la consulta Total_hombres, condigo {}".format(status))

        raw_data = response.json()
        data = raw_data['Series'][0]['OBSERVATIONS']
        df_poblacion_mayor_total_hombres = pd.DataFrame(data)

        df_poblacion_mayor_total_hombres = df_poblacion_mayor_total_hombres.rename(columns = {'OBS_VALUE' : 'Total_Hombres', 'COBER_GEO':'Entidad','TIME_PERIOD' : 'Anio'} )
        df_poblacion_mayor_total_hombres = df_poblacion_mayor_total_hombres.drop(columns = {'OBS_EXCEPTION','OBS_STATUS','OBS_SOURCE','OBS_NOTE'})
        df_poblacion_mayor_total_hombres['Entidad'] = df_poblacion_mayor_total_hombres['Entidad'].replace('00','Nacional')
        
        return df_poblacion_mayor_total_hombres

    def _total_mujeres(self,Poblacion_mayor_total_mujeres): #Prepare Total_Mujeres
        response = requests.get(Poblacion_mayor_total_mujeres)
        status = response.status_code 

        if status != 200:

            print("Error en la consulta , condigo {}".format(status))

        raw_data = response.json()
        data = raw_data['Series'][0]['OBSERVATIONS']
        df_poblacion_mayor_total_mujeres = pd.DataFrame(data)

        df_poblacion_mayor_total_mujeres = df_poblacion_mayor_total_mujeres.rename(columns = {'OBS_VALUE' : 'Total_Mujeres','COBER_GEO':'Entidad','TIME_PERIOD' : 'Anio'} )
        df_poblacion_mayor_total_mujeres = df_poblacion_mayor_total_mujeres.drop(columns = {'OBS_EXCEPTION','OBS_STATUS','OBS_SOURCE','OBS_NOTE'})
        df_poblacion_mayor_total_mujeres['Entidad'] = df_poblacion_mayor_total_mujeres['Entidad'].replace('00','Nacional')

        return df_poblacion_mayor_total_mujeres
    
    def _scrap(self, url_scraping, file_path, chromedrive_path): #Web Scraping to download the csv of puebla
        chrome_options = Options()
        chrome_options.headless = True

        #path to save file 
        chrome_options.add_experimental_option("prefs", {
        "download.default_directory": file_path,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True,
        })
        #path where we have the crhomedrive
        browser = webdriver.Chrome(chromedrive_path+'\\chromedriver.exe', options=chrome_options)
        browser.get(url_scraping)
        print('Entró a la pagina')

        #select the option in the form
        inegi = browser.find_element_by_id('Checkbox14').click()
        time.sleep(2)

        #press the buttom to do the consult
        inegi = browser.find_element_by_css_selector('input[value="Ver consulta"]').click()
        time.sleep(2)
        print('accedemos a la consulta')

        #select the federal entity in a dropdown
        inegi = Select(browser.find_element_by_id('C_Where_Entidad Federativa'))
        inegi.select_by_visible_text('  Puebla')

        #select the buttom to update the federal entity
        inegi = browser.find_element_by_name('Actualizar').click()
        time.sleep(2)
        print('Actualizo la busqueda ')

        #sleect the option of download CSV in the dropdown
        inegi = Select(browser.find_element_by_id('Select1'))
        inegi.select_by_visible_text('Texto separado por comas (.csv)')

        inegi = browser.find_element_by_id('Button1').click()
        time.sleep(2)
        print('ya descargo el archivo')
    
    def _scrap_prepared(self,path_file): #web scaping prepared to join with other dataframes

        inegiDf = pd.read_csv(path_file, header=0, skiprows=4,encoding='ISO-8859-1', sep=',')
        inegiDf = inegiDf.drop([61])

        inegi_df = inegiDf.rename(columns = {'Unnamed: 0' : 'Anio', 'Total':'Poblacion_Mayor' ,'Hombre':'Total_Hombres','Mujer':'Total_Mujeres'})
        inegi_df = inegi_df.drop(['Unnamed: 4'], axis=1)
        
        #start to prepare the dataframe to obtain column Anio and Periodo
        inegi_df[['Periodo', 'drop1','drop2','Anio']] = inegi_df.Anio.str.split(expand=True)
        inegi_df= inegi_df.drop(['drop1','drop2'], axis=1)

        #split other columns and drop unnecessary data
        inegi_df['Poblacion_Mayor'] = inegi_df.Poblacion_Mayor.str.split('|', n=0, expand = True)
        inegi_df['Total_Hombres'] = inegi_df.Total_Hombres.str.split('|', n=0, expand = True)
        inegi_df['Total_Mujeres'] = inegi_df.Total_Mujeres.str.split('|', n=0, expand = True)

        #reorganization and normalization
        inegi_df = inegi_df[['Anio','Periodo','Poblacion_Mayor','Total_Hombres','Total_Mujeres']]
        inegi_df['Periodo'] = inegi_df['Periodo'].replace('Primer','Trimestre 1')
        inegi_df['Periodo'] = inegi_df['Periodo'].replace('Segundo','Trimestre 2')
        inegi_df['Periodo'] = inegi_df['Periodo'].replace('Tercer','Trimestre 3')
        inegi_df['Periodo'] = inegi_df['Periodo'].replace('Cuarto','Trimestre 4')

        inegi_df['Entidad'] = 'Puebla'

        return inegi_df

    def _poblacion_mayor(self,df_total_hombres,df_total_mujeres,df_scrap_prepared):
        poblacion_mayor = df_total_hombres.merge(df_total_mujeres.set_index('Anio', 'Entidad'), on=['Anio', 'Entidad'])

        poblacion_mayor[['Anio', 'Periodo']] = poblacion_mayor.Anio.str.split("/",n=1, expand=True)

        poblacion_mayor['Periodo'] = poblacion_mayor['Periodo'].replace('01','Trimestre 1')
        poblacion_mayor['Periodo'] = poblacion_mayor['Periodo'].replace('02','Trimestre 2')
        poblacion_mayor['Periodo'] = poblacion_mayor['Periodo'].replace('03','Trimestre 3')
        poblacion_mayor['Periodo'] = poblacion_mayor['Periodo'].replace('04','Trimestre 4')

        poblacion_mayor['Anio'] = poblacion_mayor['Anio'].astype('int')
        poblacion_mayor['Periodo'] = poblacion_mayor['Periodo'].astype('string')
        poblacion_mayor['Total_Hombres'] = poblacion_mayor['Total_Hombres'].apply(np.float)
        poblacion_mayor['Total_Hombres'] = poblacion_mayor['Total_Hombres'].apply(np.int)
        poblacion_mayor['Total_Mujeres'] = poblacion_mayor['Total_Mujeres'].apply(np.float)
        poblacion_mayor['Total_Mujeres'] = poblacion_mayor['Total_Mujeres'].apply(np.int)
        poblacion_mayor['Entidad'] = poblacion_mayor['Entidad'].astype('string')

        poblacion_mayor['Poblacion_Mayor'] = poblacion_mayor['Total_Hombres'] + poblacion_mayor['Total_Mujeres']
        poblacion_mayor = poblacion_mayor[['Anio','Periodo','Poblacion_Mayor','Total_Hombres','Total_Mujeres', 'Entidad']]

        poblacion_mayor = pd.concat([poblacion_mayor, df_scrap_prepared], ignore_index=True, sort=False)

        return poblacion_mayor
